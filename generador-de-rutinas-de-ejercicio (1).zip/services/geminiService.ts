import { GoogleGenAI, Type } from "@google/genai";
import { UserInput, WorkoutRoutine } from '../types';

if (!process.env.API_KEY) {
    throw new Error("Missing API_KEY environment variable.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const nutritionPlanSchema = {
    type: Type.OBJECT,
    properties: {
        summary: {
            type: Type.STRING,
            description: "Un resumen breve del plan de alimentación, como el objetivo calórico y de macronutrientes."
        },
        dailyPlan: {
            type: Type.ARRAY,
            description: "Un array que contiene el plan de comidas para cada día de la semana.",
            items: {
                type: Type.OBJECT,
                properties: {
                    day: { type: Type.STRING, description: "Día de la semana (ej. 'Lunes')." },
                    meals: {
                        type: Type.ARRAY,
                        description: "Lista de comidas para el día.",
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                name: { type: Type.STRING, description: "Nombre de la comida (ej. 'Desayuno', 'Almuerzo', 'Cena', 'Snack')." },
                                description: { type: Type.STRING, description: "Descripción de la comida con ejemplos de alimentos y sugerencias de porciones y horarios." }
                            },
                            required: ["name", "description"]
                        }
                    }
                },
                required: ["day", "meals"]
            }
        }
    },
    required: ["summary", "dailyPlan"]
};

const activitySchema = {
    type: Type.ARRAY,
    description: "Lista de actividades de calentamiento o enfriamiento.",
    items: {
        type: Type.OBJECT,
        properties: {
            name: { type: Type.STRING, description: "Nombre de la actividad (ej. 'Estiramiento de cuádriceps')." },
            duration: { type: Type.STRING, description: "Duración o repeticiones (ej. '30 segundos por lado', '10 repeticiones')." }
        },
        required: ["name", "duration"]
    }
};

const workoutSchema = {
    type: Type.OBJECT,
    properties: {
        clientName: {
            type: Type.STRING,
            description: "El nombre del cliente para quien es la rutina."
        },
        weeklyRoutine: {
            type: Type.ARRAY,
            description: "Array de entrenamientos diarios para la semana. Debe coincidir con el número de días solicitado, más los días de descanso.",
            items: {
                type: Type.OBJECT,
                properties: {
                    day: {
                        type: Type.STRING,
                        description: "Día de la semana (ej. 'Lunes', 'Martes', 'Día de Descanso')."
                    },
                    focus: {
                        type: Type.STRING,
                        description: "El enfoque principal del entrenamiento del día (ej. 'Pecho y Tríceps', 'Piernas y Glúteos', 'Cardio y Abdominales', 'Descanso Activo')."
                    },
                    warmUp: {
                        ...activitySchema,
                        description: "Una serie de ejercicios de calentamiento dinámico adaptados al enfoque del día. Debe durar entre 5 y 10 minutos. Vacío si es día de descanso."
                    },
                    exercises: {
                        type: Type.ARRAY,
                        description: "Lista de ejercicios para el día. Debe estar vacía si es un día de descanso.",
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                name: { type: Type.STRING, description: "Nombre del ejercicio." },
                                sets: { type: Type.STRING, description: "Número de series (ej. '3' o '3-4')." },
                                reps: { type: Type.STRING, description: "Número de repeticiones o duración (ej. '8-12 repeticiones', '30 segundos')." },
                                description: { type: Type.STRING, description: "Breve descripción o instrucción clave para realizar el ejercicio correctamente." }
                            },
                            required: ["name", "sets", "reps", "description"]
                        }
                    },
                     coolDown: {
                        ...activitySchema,
                        description: "Una serie de estiramientos estáticos para los músculos trabajados. Debe durar entre 5 y 10 minutos. Vacío si es día de descanso."
                    },
                },
                required: ["day", "focus", "exercises"]
            }
        },
        nutritionPlan: {
            ...nutritionPlanSchema,
            description: "Un plan de alimentación sugerido para complementar la rutina de entrenamiento. Omitir si no se solicita."
        }
    },
    required: ["clientName", "weeklyRoutine"]
};

const getGoalDescription = (goal: string): string => {
    switch(goal) {
        case 'perder_peso': return 'perder peso y grasa corporal.';
        case 'ganar_musculo': return 'ganar masa muscular (hipertrofia).';
        case 'mantener_forma': return 'mantener su estado físico actual y tonificar.';
        case 'mejorar_resistencia': return 'mejorar su resistencia cardiovascular y aguante.';
        default: return 'mejorar su condición física general.'
    }
}

const getLevelDescription = (level: string): string => {
    switch(level) {
        case 'principiante': return 'Principiante (poca o ninguna experiencia en el gimnasio).';
        case 'intermedio': return 'Intermedio (entrena de forma consistente desde hace 6-12 meses).';
        case 'avanzado': return 'Avanzado (más de 1 año de experiencia y buena técnica).';
        default: return 'Principiante.'
    }
}

const getGenderDescription = (gender: string): string => {
    return gender === 'hombre' ? 'Hombre' : 'Mujer';
}

const getDietDescription = (diet: string): string => {
    switch(diet) {
        case 'balanceada': return 'una dieta balanceada y variada.';
        case 'baja_carbs': return 'una dieta baja en carbohidratos.';
        case 'vegetariana': return 'una dieta vegetariana.';
        case 'vegana': return 'una dieta vegana.';
        default: return 'una dieta balanceada.'
    }
}

const getInjuryDescription = (injuries: UserInput['injuries']): string => {
    const descriptions: string[] = [];
    if (injuries.backPain) {
        descriptions.push('dolor de espalda');
    }
    if (injuries.kneePainBoth) {
        descriptions.push('dolor en ambas rodillas');
    } else if (injuries.kneePainLeft) {
        descriptions.push('dolor en la rodilla izquierda');
    } else if (injuries.kneePainRight) {
        descriptions.push('dolor en la rodilla derecha');
    }
    if (injuries.other && injuries.other.trim() !== '') {
        descriptions.push(`además de lo siguiente: "${injuries.other.trim()}"`);
    }

    if (descriptions.length === 0) {
        return 'No se especificaron lesiones o consideraciones especiales.';
    }

    return `El cliente ha reportado ${descriptions.join(' y ')}.`;
}


export const generateWorkoutRoutine = async (userInput: UserInput): Promise<WorkoutRoutine> => {
    const { clientName, gender, age, weight, height, goal, level, days, injuries, includeNutritionPlan, dietType, allergies } = userInput;

    const nutritionPrompt = includeNutritionPlan
        ? `
        Adicionalmente, y de igual importancia, crea un plan de alimentación detallado y personalizado para ${clientName} que apoye su objetivo principal de ${getGoalDescription(goal)}.

        Instrucciones Específicas para el Plan de Alimentación:
        - **Adaptación al Objetivo:** Adapta las porciones de manera explícita al objetivo del cliente. Por ejemplo, si el objetivo es 'ganar músculo', las porciones deben ser más generosas, especialmente en proteínas y carbohidratos. Si es 'perder peso', sugiere porciones controladas y mayor énfasis en vegetales y proteínas magras para la saciedad.
        - **Estructura y Horarios:** El plan debe ser realista, con 3 comidas principales y 1-2 snacks. Para cada comida, proporciona ejemplos concretos de alimentos y sugiere un horario aproximado (ej. Desayuno: 8:00 AM, Snack: 11:00 AM).
        - **Hidratación:** Incluye una recomendación general sobre la ingesta de agua y otras bebidas saludables a lo largo del día en el resumen del plan.
        - **Preferencias Dietéticas:** El cliente prefiere ${getDietDescription(dietType)}.
        - **Restricciones:** ${allergies ? `Tiene las siguientes alergias o restricciones: ${allergies}.` : 'No se especificaron alergias.'} Es crucial que el plan evite estos ingredientes.
        - **Salida:** Incluye todo este plan detallado en el campo 'nutritionPlan' del objeto JSON.
        `
        : "No se ha solicitado un plan de alimentación. El campo 'nutritionPlan' debe ser omitido del JSON final.";

    const injuryPrompt = `
        Instrucciones Críticas de Seguridad - Lesiones del Cliente:
        - ${getInjuryDescription(injuries)}
        - Tu máxima prioridad es la seguridad. La rutina DEBE ser modificada para evitar cualquier ejercicio que pueda causar dolor o agravar estas condiciones.
        - Para el dolor de espalda, evita o modifica ejercicios como pesos muertos pesados, sentadillas con barra alta y cualquier movimiento que cause compresión espinal excesiva. Sugiere alternativas como puentes de glúteos o remos con soporte en el pecho.
        - Para el dolor de rodillas, evita o modifica sentadillas profundas, zancadas, saltos y carrera de alto impacto. Sugiere alternativas como extensiones de cuádriceps, curls de isquiotibiales, y cardio de bajo impacto como la elíptica o la bicicleta estática.
        - Si hay otras notas, adáptate de manera similar.
    `;


    const prompt = `
        Actúas como un entrenador personal de élite con más de 20 años de experiencia, especializado en transformaciones corporales para una clientela diversa. Tus métodos están influenciados por la intensidad y la ciencia de Nick Mitchell, el enfoque holístico y funcional de Matt Roberts, y la atención al detalle y sostenibilidad de Louise Parker. Tu tarea es generar un plan integral para un cliente, basado en los datos proporcionados por su entrenador.

        Datos del Cliente:
        - Nombre: ${clientName}
        - Género: ${getGenderDescription(gender)}
        - Edad: ${age} años
        - Altura: ${height} cm
        - Peso: ${weight} kg
        - Objetivo Principal: El cliente busca ${getGoalDescription(goal)}
        - Nivel de Condición Física: ${getLevelDescription(level)}
        - Días de entrenamiento por semana: ${days}

        ${injuryPrompt}

        Instrucciones para la Rutina de Entrenamiento:
        1. Considera la edad del cliente (${age} años) como un factor crucial. Para clientes más jóvenes (por debajo de 40), puedes incluir ejercicios de mayor intensidad y complejidad. Para clientes mayores (40+), prioriza la seguridad articular, incluye más ejercicios de movilidad y calentamientos más extensos. Evita ejercicios de alto impacto si no son apropiados para su edad y nivel.
        2. Basado en el género del cliente, adapta el enfoque. Para clientes masculinos ('Hombre'), puedes poner un énfasis ligeramente mayor en el desarrollo de la parte superior del cuerpo y la fuerza general, si el objetivo es ganar músculo. Para clientes femeninas ('Mujer'), considera un enfoque equilibrado, a menudo con un énfasis adicional en la parte inferior del cuerpo (glúteos y piernas) y el tono muscular general, a menos que el objetivo especifique lo contrario. Esta es una guía general, el objetivo del cliente siempre es la prioridad.
        3. Crea una rutina semanal equilibrada, segura y perfectamente adaptada al nivel de experiencia y a las consideraciones físicas del cliente.
        4. Incluye el nombre del cliente en la respuesta JSON.
        5. Distribuye los grupos musculares de forma lógica a lo largo de los días de entrenamiento para permitir una recuperación adecuada.
        6. **Calentamiento y Enfriamiento Personalizados:** Para cada día de entrenamiento, DEBES incluir una sección 'warmUp' y 'coolDown'.
            - El **'warmUp'** debe ser una rutina de calentamiento dinámico de 5-10 minutos, diseñada para preparar los músculos y articulaciones específicas que se usarán en la sesión. Por ejemplo, para un día de piernas, incluye sentadillas al aire, zancadas dinámicas y movilidad de cadera.
            - El **'coolDown'** debe ser una rutina de enfriamiento de 5-10 minutos con estiramientos estáticos, enfocados en los músculos principales trabajados durante la sesión para mejorar la flexibilidad y la recuperación.
        7. **Ejercicios Principales:** Incluye tanto ejercicios compuestos como de aislamiento. Para cada ejercicio, proporciona el nombre, series, repeticiones y una descripción muy breve pero clara sobre la técnica.
        8. **Días de Descanso:** Los días de no entrenamiento deben ser marcados como 'Día de Descanso' o 'Descanso Activo'. Para estos días, los arrays 'warmUp', 'exercises' y 'coolDown' deben estar vacíos.
        
        Instrucciones para el Plan de Alimentación (si se solicita):
        ${nutritionPrompt}

        Instrucciones Finales:
        - La respuesta DEBE ser únicamente un objeto JSON que se ajuste estrictamente al esquema proporcionado. 
        - No incluyas texto, explicaciones, saludos ni ningún carácter antes o después del objeto JSON.
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: workoutSchema,
            },
        });

        const jsonText = response.text.trim();
        const parsedResponse = JSON.parse(jsonText);
        return parsedResponse as WorkoutRoutine;

    } catch (error) {
        console.error("Error al llamar a la API de Gemini:", error);
        throw new Error("No se pudo generar el plan. Revisa los datos o intenta de nuevo más tarde.");
    }
};