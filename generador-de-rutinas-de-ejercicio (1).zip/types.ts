export interface UserInput {
    clientName: string;
    gender: 'hombre' | 'mujer';
    age: string;
    weight: string;
    height: string;
    goal: 'perder_peso' | 'ganar_musculo' | 'mantener_forma' | 'mejorar_resistencia';
    level: 'principiante' | 'intermedio' | 'avanzado';
    days: '2' | '3' | '4' | '5';
    injuries: {
        backPain: boolean;
        kneePainLeft: boolean;
        kneePainRight: boolean;
        kneePainBoth: boolean;
        other: string;
    };
    includeNutritionPlan: boolean;
    dietType: 'balanceada' | 'baja_carbs' | 'vegetariana' | 'vegana';
    allergies: string;
}

export interface Activity {
    name: string;
    duration: string;
}

export interface Exercise {
    name: string;
    sets: string;
    reps: string;
    description: string;
}

export interface DailyWorkout {
    day: string;
    focus: string;
    warmUp?: Activity[];
    exercises: Exercise[];
    coolDown?: Activity[];
}

export interface Meal {
    name: string; // e.g., 'Desayuno', 'Almuerzo'
    description: string; // e.g., 'Avena con frutas y nueces'
}

export interface DailyNutrition {
    day: string; // e.g., 'Lunes'
    meals: Meal[];
}

export interface NutritionPlan {
    summary: string; // e.g., 'Plan de 2000 kcal enfocado en proteína'
    dailyPlan: DailyNutrition[];
}

export interface WorkoutRoutine {
    clientName: string;
    weeklyRoutine: DailyWorkout[];
    nutritionPlan?: NutritionPlan;
}

export interface WorkoutRoutineWithHistory {
    id: number;
    timestamp: string;
    userInput: UserInput;
    routine: WorkoutRoutine;
}