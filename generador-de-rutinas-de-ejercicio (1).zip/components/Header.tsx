
import React from 'react';

const Header: React.FC = () => {
    return (
        <header className="w-full max-w-4xl mx-auto mb-8 text-center">
            <div className="flex items-center justify-center gap-4">
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-cyan-400">
                    <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
                </svg>
                <h1 className="text-4xl sm:text-5xl font-bold tracking-tight bg-gradient-to-r from-gray-200 to-cyan-400 text-transparent bg-clip-text">
                    Olympus Fitness Coaching
                </h1>
            </div>
            <p className="mt-2 text-lg text-gray-300">Planes de Élite para Atletas Modernos</p>
        </header>
    );
};

export default Header;