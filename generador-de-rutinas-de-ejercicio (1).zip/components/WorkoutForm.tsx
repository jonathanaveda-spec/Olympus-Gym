import React, { useState } from 'react';
import { UserInput } from '../types';

interface WorkoutFormProps {
    onSubmit: (data: UserInput) => void;
    isLoading: boolean;
}

const WorkoutForm: React.FC<WorkoutFormProps> = ({ onSubmit, isLoading }) => {
    const [formData, setFormData] = useState<UserInput>({
        clientName: '',
        gender: 'mujer',
        age: '',
        weight: '',
        height: '',
        goal: 'ganar_musculo',
        level: 'principiante',
        days: '3',
        injuries: {
            backPain: false,
            kneePainLeft: false,
            kneePainRight: false,
            kneePainBoth: false,
            other: '',
        },
        includeNutritionPlan: false,
        dietType: 'balanceada',
        allergies: '',
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value, type } = e.target;
        
        if (type === 'checkbox') {
            const { checked } = e.target as HTMLInputElement;
            setFormData(prev => ({ ...prev, [name]: checked }));
        } else {
            setFormData(prev => ({ ...prev, [name]: value }));
        }
    };
    
    const handleInjuryChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, type } = e.target;
        const value = type === 'checkbox' ? (e.target as HTMLInputElement).checked : e.target.value;

        setFormData(prev => {
            const newInjuries = { ...prev.injuries };

            if (name === 'backPain') newInjuries.backPain = value as boolean;
            if (name === 'other') newInjuries.other = value as string;

            if (name === 'kneePainLeft') newInjuries.kneePainLeft = value as boolean;
            if (name === 'kneePainRight') newInjuries.kneePainRight = value as boolean;
            
            if (name === 'kneePainBoth') {
                newInjuries.kneePainBoth = value as boolean;
                newInjuries.kneePainLeft = value as boolean;
                newInjuries.kneePainRight = value as boolean;
            }

            if (name === 'kneePainLeft' || name === 'kneePainRight') {
                newInjuries.kneePainBoth = newInjuries.kneePainLeft && newInjuries.kneePainRight;
            }
            
            return { ...prev, injuries: newInjuries };
        });
    };


    const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        if (!formData.clientName || !formData.age || !formData.weight || !formData.height) {
            alert("Por favor, completa todos los datos del cliente, incluyendo la edad.");
            return;
        }
        onSubmit(formData);
    };

    const inputClasses = "w-full bg-blue-900/50 border border-blue-700 rounded-md p-3 text-white placeholder-gray-500 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-all";
    const labelClasses = "block text-sm font-medium text-gray-300 mb-2";
    const checkboxLabelClasses = "ml-3 block text-sm font-medium text-gray-200";
    const checkboxClasses = "h-4 w-4 rounded border-gray-500 bg-blue-800 text-cyan-600 focus:ring-cyan-500";


    return (
        <form onSubmit={handleSubmit} className="space-y-6">
            <h3 className="text-lg font-semibold text-cyan-400 border-b border-blue-800 pb-2">Datos del Cliente</h3>
            <div>
                <label htmlFor="clientName" className={labelClasses}>Nombre del Cliente</label>
                <input type="text" id="clientName" name="clientName" value={formData.clientName} onChange={handleChange} placeholder="Ej: Juan Pérez" required className={inputClasses} />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                 <div>
                    <label htmlFor="gender" className={labelClasses}>Género</label>
                    <select id="gender" name="gender" value={formData.gender} onChange={handleChange} className={inputClasses}>
                        <option value="mujer">Mujer</option>
                        <option value="hombre">Hombre</option>
                    </select>
                </div>
                <div>
                    <label htmlFor="age" className={labelClasses}>Edad</label>
                    <input type="number" id="age" name="age" value={formData.age} onChange={handleChange} placeholder="Ej: 30" required className={inputClasses} />
                </div>
                <div>
                    <label htmlFor="weight" className={labelClasses}>Peso (kg)</label>
                    <input type="number" id="weight" name="weight" value={formData.weight} onChange={handleChange} placeholder="Ej: 75" required className={inputClasses} />
                </div>
                <div>
                    <label htmlFor="height" className={labelClasses}>Altura (cm)</label>
                    <input type="number" id="height" name="height" value={formData.height} onChange={handleChange} placeholder="Ej: 180" required className={inputClasses} />
                </div>
            </div>

            <h3 className="text-lg font-semibold text-cyan-400 border-b border-blue-800 pb-2 pt-2">Detalles del Plan</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                    <label htmlFor="goal" className={labelClasses}>Objetivo Principal</label>
                    <select id="goal" name="goal" value={formData.goal} onChange={handleChange} className={inputClasses}>
                        <option value="ganar_musculo">Ganar Músculo</option>
                        <option value="perder_peso">Perder Peso</option>
                        <option value="mantener_forma">Mantener Forma</option>
                        <option value="mejorar_resistencia">Mejorar Resistencia</option>
                    </select>
                </div>
                <div>
                    <label htmlFor="level" className={labelClasses}>Nivel del Cliente</label>
                    <select id="level" name="level" value={formData.level} onChange={handleChange} className={inputClasses}>
                        <option value="principiante">Principiante</option>
                        <option value="intermedio">Intermedio</option>
                        <option value="avanzado">Avanzado</option>
                    </select>
                </div>
                <div>
                    <label htmlFor="days" className={labelClasses}>Días de Entrenamiento</label>
                    <select id="days" name="days" value={formData.days} onChange={handleChange} className={inputClasses}>
                        <option value="2">2 días</option>
                        <option value="3">3 días</option>
                        <option value="4">4 días</option>
                        <option value="5">5 días</option>
                    </select>
                </div>
            </div>
            
            <h3 className="text-lg font-semibold text-cyan-400 border-b border-blue-800 pb-2 pt-2">Lesiones o Consideraciones</h3>
            <div className="space-y-4 p-4 bg-blue-950/50 rounded-lg border border-blue-800">
                <div className="flex items-center">
                    <input type="checkbox" id="backPain" name="backPain" checked={formData.injuries.backPain} onChange={handleInjuryChange} className={checkboxClasses}/>
                    <label htmlFor="backPain" className={checkboxLabelClasses}>Dolor de espalda</label>
                </div>
                
                <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Dolor de rodillas</label>
                    <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
                        <div className="flex items-center">
                            <input type="checkbox" id="kneePainLeft" name="kneePainLeft" checked={formData.injuries.kneePainLeft} onChange={handleInjuryChange} className={checkboxClasses} />
                            <label htmlFor="kneePainLeft" className="ml-2 text-sm text-gray-200">Izquierda</label>
                        </div>
                        <div className="flex items-center">
                            <input type="checkbox" id="kneePainRight" name="kneePainRight" checked={formData.injuries.kneePainRight} onChange={handleInjuryChange} className={checkboxClasses} />
                            <label htmlFor="kneePainRight" className="ml-2 text-sm text-gray-200">Derecha</label>
                        </div>
                         <div className="flex items-center">
                            <input type="checkbox" id="kneePainBoth" name="kneePainBoth" checked={formData.injuries.kneePainBoth} onChange={handleInjuryChange} className={checkboxClasses} />
                            <label htmlFor="kneePainBoth" className="ml-2 text-sm text-gray-200">Ambas</label>
                        </div>
                    </div>
                </div>
                
                <div>
                    <label htmlFor="otherInjuries" className={labelClasses}>Otras lesiones o notas</label>
                    <textarea 
                        id="otherInjuries" 
                        name="other" 
                        rows={2}
                        value={formData.injuries.other} 
                        onChange={handleInjuryChange}
                        placeholder="Ej: Dolor en el hombro derecho, tendinitis..." 
                        className={inputClasses} 
                    />
                </div>
            </div>

            <h3 className="text-lg font-semibold text-cyan-400 border-b border-blue-800 pb-2 pt-2">Plan de Alimentación (Opcional)</h3>
            <div className="space-y-4">
                <div className="flex items-center">
                    <input 
                        type="checkbox" 
                        id="includeNutritionPlan" 
                        name="includeNutritionPlan" 
                        checked={formData.includeNutritionPlan}
                        onChange={handleChange}
                        className={checkboxClasses}
                    />
                    <label htmlFor="includeNutritionPlan" className={checkboxLabelClasses}>
                        Incluir plan de alimentación
                    </label>
                </div>

                {formData.includeNutritionPlan && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-4 bg-blue-950/50 rounded-lg border border-blue-800 animate-fade-in">
                        <div>
                            <label htmlFor="dietType" className={labelClasses}>Tipo de Dieta</label>
                            <select id="dietType" name="dietType" value={formData.dietType} onChange={handleChange} className={inputClasses}>
                                <option value="balanceada">Balanceada</option>
                                <option value="baja_carbs">Baja en Carbohidratos</option>
                                <option value="vegetariana">Vegetariana</option>
                                <option value="vegana">Vegana</option>
                            </select>
                        </div>
                        <div>
                            <label htmlFor="allergies" className={labelClasses}>Alergias o Restricciones</label>
                            <input type="text" id="allergies" name="allergies" value={formData.allergies} onChange={handleChange} placeholder="Ej: Intolerancia a la lactosa..." className={inputClasses} />
                        </div>
                    </div>
                )}
            </div>


            <div className="pt-2">
                <button 
                    type="submit" 
                    disabled={isLoading}
                    className="w-full flex items-center justify-center bg-cyan-600 hover:bg-cyan-500 disabled:bg-gray-600 disabled:cursor-not-allowed text-white font-bold py-3 px-4 rounded-lg transition-all duration-300 shadow-lg shadow-cyan-900/50 transform hover:scale-105"
                >
                    {isLoading ? (
                        <>
                            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="O 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            Generando...
                        </>
                    ) : (
                        "Generar Plan para Cliente"
                    )}
                </button>
            </div>
        </form>
    );
};

export default WorkoutForm;