import React from 'react';
import { WorkoutRoutine, DailyWorkout, Exercise, NutritionPlan, DailyNutrition, Activity } from '../types';
import { getWorkoutImage, getMealImage } from '../utils';

interface WorkoutDisplayProps {
    routine: WorkoutRoutine;
}

const ExerciseCard: React.FC<{ exercise: Exercise }> = ({ exercise }) => (
    <div className="bg-blue-900 p-4 rounded-lg border border-blue-800 hover:bg-blue-800/50 transition-colors duration-200">
        <h4 className="font-semibold text-cyan-300">{exercise.name}</h4>
        <div className="flex items-center space-x-4 mt-2 text-sm text-gray-300">
            <span className="bg-blue-800 px-2 py-1 rounded">Series: <strong>{exercise.sets}</strong></span>
            <span className="bg-blue-800 px-2 py-1 rounded">Reps: <strong>{exercise.reps}</strong></span>
        </div>
        <p className="mt-3 text-sm text-gray-400">{exercise.description}</p>
    </div>
);

const ActivityList: React.FC<{ title: string; activities: Activity[]; icon: React.ReactNode }> = ({ title, activities, icon }) => (
    <div className="bg-blue-950/50 p-3 rounded-lg border border-blue-800">
        <div className="flex items-center gap-2 mb-2">
            {icon}
            <h5 className="font-semibold text-cyan-400 text-sm">{title}</h5>
        </div>
        <ul className="space-y-1 text-sm text-gray-300 pl-2">
            {activities.map((activity, index) => (
                <li key={index} className="flex items-start">
                    <span className="mr-2 text-cyan-500">&#8227;</span>
                    <span>{activity.name}: <span className="font-medium text-gray-200">{activity.duration}</span></span>
                </li>
            ))}
        </ul>
    </div>
);

const DayCard: React.FC<{ dayWorkout: DailyWorkout }> = ({ dayWorkout }) => {
    const isRestDay = dayWorkout.exercises.length === 0;

    return (
        <div className="bg-blue-900/60 rounded-xl shadow-lg border border-blue-800 overflow-hidden flex flex-col">
            <img 
                src={getWorkoutImage(dayWorkout.focus)} 
                alt={`Imagen de referencia para ${dayWorkout.focus}`}
                className="w-full h-40 object-cover"
                loading="lazy"
            />
            <div className={`p-4 ${isRestDay ? 'bg-emerald-800/50' : 'bg-blue-800/50'}`}>
                <h3 className="text-xl font-bold">{dayWorkout.day}</h3>
                <p className={`text-sm ${isRestDay ? 'text-emerald-300' : 'text-cyan-400'}`}>{dayWorkout.focus}</p>
            </div>
            <div className="p-4 space-y-4 flex-grow">
                {isRestDay ? (
                    <div className="flex items-center justify-center h-full">
                        <p className="text-gray-300">¡Disfruta del descanso y recuperación!</p>
                    </div>
                ) : (
                    <>
                        {dayWorkout.warmUp && dayWorkout.warmUp.length > 0 && (
                            <ActivityList 
                                title="Calentamiento" 
                                activities={dayWorkout.warmUp} 
                                icon={<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-orange-400"><path d="M14.5 4h-5L7 7l-4 6v3h12v-3l-4-6-2.5-3z"></path><circle cx="12" cy="4" r="2"></circle></svg>}
                            />
                        )}

                        <div className="space-y-4 my-4">
                            {dayWorkout.exercises.map((exercise, index) => (
                                <ExerciseCard key={index} exercise={exercise} />
                            ))}
                        </div>

                        {dayWorkout.coolDown && dayWorkout.coolDown.length > 0 && (
                             <ActivityList 
                                title="Enfriamiento" 
                                activities={dayWorkout.coolDown} 
                                icon={<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-sky-400"><path d="M12 2a5 5 0 0 0-5 5c0 1.66.84 3.12 2.06 4L6 22h12l-3.06-11A5 5 0 0 0 12 2z"></path></svg>}
                            />
                        )}
                    </>
                )}
            </div>
        </div>
    );
};

const NutritionDayCard: React.FC<{ dayNutrition: DailyNutrition }> = ({ dayNutrition }) => (
    <div className="bg-blue-900/60 rounded-xl shadow-lg border border-blue-800 overflow-hidden flex flex-col">
        <div className="p-4 bg-blue-800/50">
            <h3 className="text-xl font-bold">{dayNutrition.day}</h3>
        </div>
        <div className="p-4 space-y-4">
            {dayNutrition.meals.map((meal, index) => (
                 <div key={index} className="bg-blue-900 rounded-lg border border-blue-800 overflow-hidden shadow-md transition-transform hover:scale-105 duration-300">
                    <img 
                        src={getMealImage(meal.name)} 
                        alt={`Imagen de ${meal.name}`}
                        className="w-full h-32 object-cover"
                        loading="lazy"
                    />
                    <div className="p-3">
                        <h4 className="font-semibold text-cyan-300">{meal.name}</h4>
                        <p className="mt-1 text-sm text-gray-300">{meal.description}</p>
                    </div>
                </div>
            ))}
        </div>
    </div>
);

const NutritionPlanDisplay: React.FC<{ plan: NutritionPlan }> = ({ plan }) => (
    <div className="mt-12">
        <div className="text-center mb-8">
            <h2 className="text-3xl font-bold">Plan de Alimentación Sugerido</h2>
            <p className="text-gray-400 mt-2 max-w-2xl mx-auto">{plan.summary}</p>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {plan.dailyPlan.map((day, index) => (
                <NutritionDayCard key={index} dayNutrition={day} />
            ))}
        </div>
    </div>
);


const WorkoutDisplay: React.FC<WorkoutDisplayProps> = ({ routine }) => {
    return (
        <div id="printable-area" className="animate-fade-in space-y-12">
            <div>
                <h2 className="text-3xl font-bold text-center mb-6">Plan de Entrenamiento para <span className="text-cyan-400">{routine.clientName}</span></h2>
                <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                    {routine.weeklyRoutine.map((dayWorkout, index) => (
                        <DayCard key={index} dayWorkout={dayWorkout} />
                    ))}
                </div>
            </div>
            
            {routine.nutritionPlan && (
                <>
                    <hr className="border-blue-800 my-8" />
                    <NutritionPlanDisplay plan={routine.nutritionPlan} />
                </>
            )}
        </div>
    );
};

export default WorkoutDisplay;