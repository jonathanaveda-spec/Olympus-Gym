import React from 'react';
import { WorkoutRoutineWithHistory, UserInput } from '../types';

interface HistoryPanelProps {
    history: WorkoutRoutineWithHistory[];
    onSelectRoutine: (routine: WorkoutRoutineWithHistory) => void;
    onClearHistory: () => void;
}

const goalMap: Record<UserInput['goal'], string> = {
    'ganar_musculo': 'Ganar Músculo',
    'perder_peso': 'Perder Peso',
    'mantener_forma': 'Mantener Forma',
    'mejorar_resistencia': 'Mejorar Resistencia',
};

const genderMap: Record<UserInput['gender'], string> = {
    'hombre': 'Hombre',
    'mujer': 'Mujer',
};


const formatTimestamp = (timestamp: string): string => {
    return new Date(timestamp).toLocaleString('es-ES', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
    });
};

const HistoryPanel: React.FC<HistoryPanelProps> = ({ history, onSelectRoutine, onClearHistory }) => {
    if (history.length === 0) {
        return null;
    }

    return (
        <aside className="w-full max-w-4xl mx-auto mt-12 animate-fade-in">
            <div className="bg-blue-900/40 rounded-xl shadow-2xl p-6 sm:p-8 border border-blue-800 backdrop-blur-sm">
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-2xl font-bold text-cyan-400">Historial de Clientes</h2>
                    <button
                        onClick={onClearHistory}
                        className="text-sm text-gray-400 hover:text-red-400 transition-colors flex items-center gap-1"
                        aria-label="Borrar historial"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
                        <span>Borrar</span>
                    </button>
                </div>
                <ul className="space-y-3 max-h-80 overflow-y-auto pr-2">
                    {history.map((item) => (
                        <li key={item.id}>
                            <button
                                onClick={() => onSelectRoutine(item)}
                                className="w-full text-left p-4 bg-blue-800/40 hover:bg-blue-800 border border-blue-700 rounded-lg transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-cyan-500 group"
                            >
                                <div className="flex justify-between items-start">
                                    <div className="flex-grow">
                                        <div className="flex items-center gap-3">
                                            <p className="font-semibold text-white">
                                                Plan para: <span className="text-cyan-300">{item.userInput.clientName}</span>
                                            </p>
                                            {item.routine.nutritionPlan && (
                                                <span className="text-xs font-medium bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full">
                                                    + Nutrición
                                                </span>
                                            )}
                                        </div>
                                        <p className="text-sm text-gray-400 mt-1">
                                            {genderMap[item.userInput.gender]}, {item.userInput.age} años - {goalMap[item.userInput.goal]} ({item.userInput.days} días) - Creado: {formatTimestamp(item.timestamp)}
                                        </p>
                                    </div>
                                    <div className="flex-shrink-0 mt-2">
                                     <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-cyan-400 transition-transform transform group-hover:translate-x-1"><polyline points="9 18 15 12 9 6"></polyline></svg>
                                    </div>
                                </div>
                            </button>
                        </li>
                    ))}
                </ul>
            </div>
        </aside>
    );
};

export default HistoryPanel;