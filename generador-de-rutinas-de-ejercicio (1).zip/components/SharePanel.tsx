import React, { useState, useCallback } from 'react';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { WorkoutRoutine } from '../types';
import { getWorkoutImage } from '../utils';

interface SharePanelProps {
    routine: WorkoutRoutine;
}

const formatRoutineForClipboard = (routine: WorkoutRoutine): string => {
    let text = `*Plan de Fitness para ${routine.clientName}*\n\n`;
    text += "--------------------------------------\n";
    text += "🏋️‍♂️ *RUTINA DE ENTRENAMIENTO*\n";
    text += "--------------------------------------\n\n";

    routine.weeklyRoutine.forEach(day => {
        text += `*${day.day} - ${day.focus}*\n`;
        if (day.exercises.length > 0) {
            if (day.warmUp && day.warmUp.length > 0) {
                text += `  *Calentamiento:*\n`;
                day.warmUp.forEach(act => {
                    text += `    - ${act.name} (${act.duration})\n`;
                });
            }
            day.exercises.forEach(ex => {
                text += `- *${ex.name}:* ${ex.sets} series x ${ex.reps} repeticiones\n`;
                text += `  _${ex.description}_\n`;
            });
            if (day.coolDown && day.coolDown.length > 0) {
                text += `  *Enfriamiento:*\n`;
                day.coolDown.forEach(act => {
                    text += `    - ${act.name} (${act.duration})\n`;
                });
            }
        } else {
            text += "_Descanso y recuperación._\n";
        }
        text += "\n";
    });

    if (routine.nutritionPlan) {
        text += "--------------------------------------\n";
        text += "🍎 *PLAN DE ALIMENTACIÓN*\n";
        text += "--------------------------------------\n\n";
        text += `*Resumen:* ${routine.nutritionPlan.summary}\n\n`;

        routine.nutritionPlan.dailyPlan.forEach(day => {
            text += `*${day.day}*\n`;
            day.meals.forEach(meal => {
                text += `- *${meal.name}:* ${meal.description}\n`;
            });
            text += "\n";
        });
    }

    text += "_Generado con Olympus Fitness Coaching AI_";
    return text;
};

const SharePanel: React.FC<SharePanelProps> = ({ routine }) => {
    const [copyButtonText, setCopyButtonText] = useState('Copiar Resumen');
    const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);

    const handleCopyToClipboard = useCallback(() => {
        const textToCopy = formatRoutineForClipboard(routine);
        navigator.clipboard.writeText(textToCopy).then(() => {
            setCopyButtonText('¡Copiado!');
            setTimeout(() => setCopyButtonText('Copiar Resumen'), 2000);
        }).catch(err => {
            console.error('Error al copiar al portapapeles', err);
            alert('No se pudo copiar el texto. Inténtalo de nuevo.');
        });
    }, [routine]);

    const handleShareOnWhatsApp = useCallback(() => {
        const textToCopy = formatRoutineForClipboard(routine);
        const encodedText = encodeURIComponent(textToCopy);
        const whatsappUrl = `https://wa.me/?text=${encodedText}`;
        window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
    }, [routine]);

    const getImageAsBase64 = async (url: string): Promise<string | null> => {
        try {
            const response = await fetch(url);
            if (!response.ok) throw new Error('Network response was not ok.');
            const blob = await response.blob();
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onloadend = () => resolve(reader.result as string);
                reader.onerror = reject;
                reader.readAsDataURL(blob);
            });
        } catch (error) {
            console.warn(`Could not fetch image due to CORS or network error: ${url}`, error);
            return null;
        }
    };

    const handleGeneratePdf = async () => {
        setIsGeneratingPdf(true);
        try {
            const doc = new jsPDF();
            const pageWidth = doc.internal.pageSize.getWidth();
            let y = 15;

            doc.setFontSize(22);
            doc.text(`Plan de Fitness para ${routine.clientName}`, pageWidth / 2, y, { align: 'center' });
            y += 15;

            doc.setFontSize(18);
            doc.text('Rutina de Entrenamiento', 14, y);
            y += 10;
            
            const autoTableDoc = doc as any;

            for (const day of routine.weeklyRoutine) {
                if (y > doc.internal.pageSize.getHeight() - 80) {
                    doc.addPage();
                    y = 15;
                }

                doc.setFontSize(14);
                doc.setTextColor(22, 160, 133); // Teal
                doc.text(`${day.day} - ${day.focus}`, 14, y);
                doc.setTextColor(0, 0, 0);
                y += 8;
                
                const imageUrl = getWorkoutImage(day.focus);
                const imageData = await getImageAsBase64(imageUrl);
                if (imageData) {
                    const imgWidth = 60;
                    const imgHeight = (imgWidth / 16) * 9;
                    doc.addImage(imageData, 'JPEG', 14, y, imgWidth, imgHeight);
                    y += imgHeight + 5;
                }

                if (day.exercises.length > 0) {
                    if (day.warmUp && day.warmUp.length > 0) {
                        autoTable(doc, {
                            startY: y,
                            head: [['Calentamiento', 'Duración']],
                            body: day.warmUp.map(act => [act.name, act.duration]),
                            theme: 'grid',
                            headStyles: { fillColor: [243, 156, 18] }, // Orange
                        });
                        y = autoTableDoc.lastAutoTable.finalY + 5;
                    }

                    autoTable(doc, {
                        startY: y,
                        head: [['Ejercicio', 'Series', 'Reps', 'Descripción']],
                        body: day.exercises.map(ex => [ex.name, ex.sets, ex.reps, ex.description]),
                        theme: 'grid',
                        headStyles: { fillColor: [22, 160, 133] },
                    });
                    y = autoTableDoc.lastAutoTable.finalY;

                    if (day.coolDown && day.coolDown.length > 0) {
                         y += 5;
                         autoTable(doc, {
                            startY: y,
                            head: [['Enfriamiento', 'Duración']],
                            body: day.coolDown.map(act => [act.name, act.duration]),
                            theme: 'grid',
                            headStyles: { fillColor: [52, 152, 219] }, // Blue
                        });
                        y = autoTableDoc.lastAutoTable.finalY;
                    }
                    y += 10;
                } else {
                    doc.setFontSize(12);
                    doc.text('Día de descanso y recuperación.', 14, y);
                    y += 10;
                }
            }

            if (routine.nutritionPlan) {
                doc.addPage();
                y = 15;
                doc.setFontSize(18);
                doc.text('Plan de Alimentación', 14, y);
                y += 8;
                doc.setFontSize(12);
                const summaryLines = doc.splitTextToSize(routine.nutritionPlan.summary, pageWidth - 28);
                doc.text(summaryLines, 14, y);
                y += summaryLines.length * 5 + 5;

                autoTable(doc, {
                    startY: y,
                    head: [['Día', 'Comida', 'Descripción']],
                    body: routine.nutritionPlan.dailyPlan.flatMap(day =>
                        day.meals.map((meal, index) =>
                            index === 0 ? [day.day, meal.name, meal.description] : ['', meal.name, meal.description]
                        )
                    ),
                    theme: 'striped',
                    headStyles: { fillColor: [46, 204, 113] },
                    didParseCell: (data) => {
                        if (data.section === 'body' && data.column.index === 0 && data.cell.raw !== '') {
                            data.cell.styles.valign = 'middle';
                            data.cell.styles.fontStyle = 'bold';
                        }
                    },
                });
            }
            
            doc.save(`plan-fitness-${routine.clientName.replace(/\s/g, '_')}.pdf`);

        } catch (error) {
            console.error("Error al generar el PDF:", error);
            alert("Hubo un error al generar el PDF. Revisa la consola para más detalles.");
        } finally {
            setIsGeneratingPdf(false);
        }
    };

    return (
        <div id="share-panel" className="w-full max-w-4xl mx-auto mt-10 animate-fade-in">
            <div className="bg-blue-900/40 rounded-xl shadow-2xl p-6 sm:p-8 border border-blue-800 backdrop-blur-sm">
                <h2 className="text-2xl font-bold text-cyan-400 mb-6 text-center">Exportar y Compartir</h2>
                <div className="flex flex-col sm:flex-row gap-4 justify-center flex-wrap">
                    <button
                        onClick={handleCopyToClipboard}
                        className="flex items-center justify-center gap-2 w-full sm:w-auto bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-3 px-6 rounded-lg transition-all duration-300 transform hover:scale-105"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                            <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                        </svg>
                        <span>{copyButtonText}</span>
                    </button>
                    <button
                        onClick={handleShareOnWhatsApp}
                        className="flex items-center justify-center gap-2 w-full sm:w-auto bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 px-6 rounded-lg transition-all duration-300 transform hover:scale-105"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.894 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.886-.001 2.267.651 4.383 1.803 6.243l-.499 1.805 1.807-.499z"/>
                        </svg>
                        <span>Compartir por WhatsApp</span>
                    </button>
                    <button
                        onClick={handleGeneratePdf}
                        disabled={isGeneratingPdf}
                        className="flex items-center justify-center gap-2 w-full sm:w-auto bg-gray-600 hover:bg-gray-500 disabled:bg-gray-700 disabled:cursor-wait text-white font-bold py-3 px-6 rounded-lg transition-all duration-300 transform hover:scale-105"
                    >
                        {isGeneratingPdf ? (
                            <>
                                <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                                <span>Generando PDF...</span>
                            </>
                        ) : (
                           <>
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                    <polyline points="6 9 6 2 18 2 18 9"></polyline>
                                    <path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path>
                                    <rect x="6" y="14" width="12" height="8"></rect>
                                </svg>
                                <span>Guardar como PDF</span>
                           </>
                        )}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default SharePanel;