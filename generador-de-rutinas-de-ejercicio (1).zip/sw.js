const CACHE_NAME = 'olympus-fitness-v1';
const URLS_TO_CACHE = [
  '/',
  '/index.html',
];

// Instalar el service worker y cachear los recursos principales de la aplicación.
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Cache abierta');
        return cache.addAll(URLS_TO_CACHE);
      })
  );
});

// Interceptar peticiones de red.
self.addEventListener('fetch', event => {
  // Solo gestionar peticiones GET.
  if (event.request.method !== 'GET') {
    return;
  }

  // Las llamadas a la API de IA siempre deben ir a la red.
  const isApiCall = event.request.url.includes('generativelanguage.googleapis.com');
  if (isApiCall) {
    return; // Dejar que el navegador la gestione.
  }

  // Estrategia: Cache-First, luego Network.
  event.respondWith(
    caches.open(CACHE_NAME).then(async (cache) => {
      // Intentar obtener la respuesta desde la caché.
      const cachedResponse = await cache.match(event.request);
      if (cachedResponse) {
        return cachedResponse;
      }
      
      // Si no está en caché, ir a la red.
      try {
        const networkResponse = await fetch(event.request);
        // Si la petición es exitosa, clonarla y guardarla en caché para futuras visitas.
        if (networkResponse.ok) {
           cache.put(event.request, networkResponse.clone());
        }
        return networkResponse;
      } catch (error) {
        // La petición falló, probablemente porque el usuario está sin conexión.
        console.error('La petición de red ha fallado:', error);
        throw error;
      }
    })
  );
});

// Activar el service worker y limpiar cachés antiguas.
self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});
