export const getWorkoutImage = (focus: string): string => {
    const f = focus.toLowerCase();
    if (f.includes('pecho') || f.includes('tríceps') || f.includes('empuje')) {
        return 'https://images.pexels.com/photos/3838329/pexels-photo-3838329.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop';
    }
    if (f.includes('pierna') || f.includes('glúteos')) {
        return 'https://images.pexels.com/photos/6551068/pexels-photo-6551068.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop';
    }
    if (f.includes('espalda') || f.includes('bíceps') || f.includes('tracción')) {
        return 'https://images.pexels.com/photos/4164765/pexels-photo-4164765.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop';
    }
    if (f.includes('hombro') || f.includes('brazos')) {
        return 'https://images.pexels.com/photos/8109038/pexels-photo-8109038.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop';
    }
    if (f.includes('cardio') || f.includes('resistencia') || f.includes('abdominales')) {
        return 'https://images.pexels.com/photos/4761793/pexels-photo-4761793.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop';
    }
     if (f.includes('descanso')) {
        return 'https://images.pexels.com/photos/7031706/pexels-photo-7031706.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop';
    }
    return 'https://images.pexels.com/photos/260352/pexels-photo-260352.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop';
};


export const getMealImage = (mealName: string): string => {
    const name = mealName.toLowerCase();
    if (name.includes('desayuno')) {
        return 'https://images.pexels.com/photos/103124/pexels-photo-103124.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop';
    }
    if (name.includes('almuerzo') || name.includes('comida')) {
        return 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop';
    }
    if (name.includes('cena')) {
        return 'https://images.pexels.com/photos/769289/pexels-photo-769289.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop';
    }
    if (name.includes('snack') || name.includes('merienda')) {
        return 'https://images.pexels.com/photos/1395967/pexels-photo-1395967.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop';
    }
    return 'https://images.pexels.com/photos/1435904/pexels-photo-1435904.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop';
};