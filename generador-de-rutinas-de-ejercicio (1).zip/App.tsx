import React, { useState, useCallback, useEffect } from 'react';
import { UserInput, WorkoutRoutine, WorkoutRoutineWithHistory } from './types';
import { generateWorkoutRoutine } from './services/geminiService';
import Header from './components/Header';
import WorkoutForm from './components/WorkoutForm';
import WorkoutDisplay from './components/WorkoutDisplay';
import HistoryPanel from './components/HistoryPanel';
import SharePanel from './components/SharePanel';

const Loader: React.FC = () => (
    <div className="flex flex-col items-center justify-center p-8 text-center">
        <svg className="animate-spin h-10 w-10 text-cyan-400 mb-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        <p className="text-lg text-gray-300">Generando el plan integral para el cliente...</p>
        <p className="text-sm text-gray-400">Esto puede tardar un momento.</p>
    </div>
);

const ErrorMessage: React.FC<{ message: string }> = ({ message }) => (
    <div className="bg-red-900/50 border border-red-600 text-red-300 px-4 py-3 rounded-lg relative my-4" role="alert">
        <strong className="font-bold">¡Error! </strong>
        <span className="block sm:inline">{message}</span>
    </div>
);


const App: React.FC = () => {
    const [workoutRoutine, setWorkoutRoutine] = useState<WorkoutRoutine | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [history, setHistory] = useState<WorkoutRoutineWithHistory[]>([]);

    useEffect(() => {
        try {
            const storedHistory = localStorage.getItem('workoutHistory');
            if (storedHistory) {
                setHistory(JSON.parse(storedHistory));
            }
        } catch (err) {
            console.error("Failed to load history from localStorage", err);
            localStorage.removeItem('workoutHistory');
        }
    }, []);

    const handleGenerateRoutine = useCallback(async (userInput: UserInput) => {
        setIsLoading(true);
        setError(null);
        setWorkoutRoutine(null);
        try {
            const routine = await generateWorkoutRoutine(userInput);
            setWorkoutRoutine(routine);

            const newHistoryEntry: WorkoutRoutineWithHistory = {
                id: Date.now(),
                timestamp: new Date().toISOString(),
                userInput,
                routine,
            };
            
            setHistory(prevHistory => {
                const updatedHistory = [newHistoryEntry, ...prevHistory].slice(0, 20); // Keep last 20 routines
                try {
                    localStorage.setItem('workoutHistory', JSON.stringify(updatedHistory));
                } catch (err) {
                    console.error("Failed to save history to localStorage", err);
                }
                return updatedHistory;
            });

        } catch (err) {
            setError(err instanceof Error ? err.message : 'Ocurrió un error desconocido al generar la rutina.');
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    }, []);
    
    const handleSelectFromHistory = useCallback((selectedItem: WorkoutRoutineWithHistory) => {
        setWorkoutRoutine(selectedItem.routine);
        setError(null);
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }, []);

    const handleClearHistory = useCallback(() => {
        if (window.confirm('¿Estás seguro de que quieres borrar todo el historial?')) {
            setHistory([]);
            setWorkoutRoutine(null);
            try {
                localStorage.removeItem('workoutHistory');
            } catch (err) {
                console.error("Failed to clear history from localStorage", err);
            }
        }
    }, []);
    
    return (
        <div className="min-h-screen flex flex-col items-center p-4 sm:p-6 lg:p-8">
            <Header />
            <main className="w-full max-w-4xl mx-auto">
                <div className="bg-blue-900/40 rounded-xl shadow-2xl p-6 sm:p-8 border border-blue-800 backdrop-blur-sm">
                    <WorkoutForm onSubmit={handleGenerateRoutine} isLoading={isLoading} />
                </div>

                <div className="mt-8">
                    {isLoading && <Loader />}
                    {error && <ErrorMessage message={error} />}
                    {workoutRoutine ? (
                        <>
                            <WorkoutDisplay routine={workoutRoutine} />
                            <SharePanel routine={workoutRoutine} />
                        </>
                    ) : (
                        !isLoading && !error && (
                            <div className="text-center p-8 bg-blue-900/40 rounded-xl border border-blue-800">
                                <h2 className="text-2xl font-bold text-cyan-400">Bienvenido a Olympus Fitness Coaching</h2>
                                <p className="mt-2 text-gray-300">
                                    Completa el formulario con los datos del cliente para generar un plan de entrenamiento base.
                                    <br />
                                    Opcionalmente, puedes incluir una guía de alimentación personalizada.
                                </p>
                            </div>
                        )
                    )}
                </div>
            </main>

            <HistoryPanel 
                history={history}
                onSelectRoutine={handleSelectFromHistory}
                onClearHistory={handleClearHistory}
            />
        </div>
    );
};

export default App;